package com.udacity.jdnd.course3.critter.repository;


import com.udacity.jdnd.course3.critter.entity.Employee;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;



@Repository
@Transactional
//JpaRepository contains all CRUD Repository API manages with Schedule Entity
public interface ScheduleRepository extends JpaRepository<Schedule,Long> {
    List<Schedule> getAll_ContainsPets(Pet pet);

    List<Schedule> getAll_ContainsEmployee(Employee employee);
}
