package com.udacity.jdnd.course3.critter.entity;

import jdk.jfr.DataAmount;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


//@Data is a shortcut annotation that bundles the features of @ToString, @EqualsAndHashCode, @Getter / @Setter
@Data
@Entity
//@Data has @RequiredArgsConstructor so use @NoArgsConstructor
//generates a constructor with no parameters
@NoArgsConstructor
public class Customer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String phoneNumber;

    private String name;

    private String notes;



    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = Pet.class)
   // @LazyCollection(LazyCollectionOption.TRUE)
    private List<Pet> petList;

    public void addPet(Pet pet){

        petList.add(pet);
    }

    public List<Pet> getPetList() {
        return petList;
    }

    public void setPetList(List<Pet> petList) {
        this.petList = petList;
    }


}
