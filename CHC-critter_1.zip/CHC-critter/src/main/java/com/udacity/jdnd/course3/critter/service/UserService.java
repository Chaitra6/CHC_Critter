package com.udacity.jdnd.course3.critter.service;


import com.udacity.jdnd.course3.critter.entity.Customer;
import com.udacity.jdnd.course3.critter.entity.Employee;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.repository.CustomerRepository;
import com.udacity.jdnd.course3.critter.repository.EmployeeRepository;
import com.udacity.jdnd.course3.critter.repository.PetRepository;
import com.udacity.jdnd.course3.critter.user.EmployeeSkill;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;


// Includes both Employee and Customer methods

@Service
@Transactional
public class UserService {
    // Include Employee , Customer and pet Repository, Autowire them

    @Autowired
    private CustomerRepository customerRepo;

    @Autowired
    private EmployeeRepository empRepo ;

    @Autowired
    private PetRepository petRepo ;


    //___________________________ EMPLOYEE _____________________________


    public Employee getEmplByID( long empID){

     // Use optional to check if the emp is present or not
        Optional<Employee>  opEmp = Optional.of(empRepo.getOne(empID));

        if(opEmp != null){
            Employee employee = opEmp.get();
            return employee;
        }
        else return null;
    }


    // Saves the given Employee
    public Employee saveEmployee(Employee emp){

        Employee employee = empRepo.save(emp);
        return employee;

    }


    public List<Employee> getServiceEmployees(Set<EmployeeSkill> skill_Set, LocalDate date){

        // get all the employees
        List<Employee> empList = empRepo.findAll();

        List<Employee> empWithSkillsAndAvailable = new ArrayList<>();

        for (Employee emp : empList){
            if(emp.getDaysAvailable() != null && emp.getSkills() != null){
                if(emp.getDaysAvailable().contains(date.getDayOfWeek()) && emp.getSkills().containsAll(skill_Set)){


                    // add the employee to empWithSkillsAndAvailable list
                    empWithSkillsAndAvailable.add(emp);
                }
            }
        }

        // return the list
        return empWithSkillsAndAvailable;
    }



    public void setEmpAvailability(long empID, Set<DayOfWeek> daysSet){

        // Use optional to check if the emp is present or not
        Optional<Employee>  opEmp = Optional.of(empRepo.getOne(empID));

        if(opEmp != null){
            Employee employee = opEmp.get();
            employee.setDaysAvailable(daysSet);
            empRepo.save(employee);
        }
    }





    //______________________________CUSTOMER________________________________




// save customer in the repo
    public Customer saveCustomer(Customer customer){
        Customer cus = customerRepo.save(customer);
        return cus;
    }


// get customer by customer ID
    public Customer getCustomerByCusID(long cID){
        // Use optional to check if the customer is present or not
        Optional<Customer> opCus = Optional.of(customerRepo.getOne(cID));

        if(opCus.isPresent()){
            Customer customer = opCus.get();
            return customer;
        }
        else return null;
    }


    // get all the customers
    public List<Customer> getAllCustomer(){
        List<Customer> cusList = customerRepo.findAll();
        return cusList;
    }


    // Find Pet Owner by PetID
    public Customer getCustomerByPetID(long pID) {
        // Get the pet and then get its owner
        Pet pet = petRepo.getOne(pID);
        return pet.getCustomer();
    }

}
