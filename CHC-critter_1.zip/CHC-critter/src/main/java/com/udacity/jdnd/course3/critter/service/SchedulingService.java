package com.udacity.jdnd.course3.critter.service;

import com.udacity.jdnd.course3.critter.entity.Customer;
import com.udacity.jdnd.course3.critter.entity.Employee;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.entity.Schedule;
import com.udacity.jdnd.course3.critter.repository.CustomerRepository;
import com.udacity.jdnd.course3.critter.repository.EmployeeRepository;
import com.udacity.jdnd.course3.critter.repository.PetRepository;
import com.udacity.jdnd.course3.critter.repository.ScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SchedulingService {

    //import all the repositories, User and PetService

    @Autowired
    private ScheduleRepository scheduleRepository;

    @Autowired
    private CustomerRepository customerRepo;

    @Autowired
    private EmployeeRepository empRepo;

    @Autowired
    private PetRepository petRepo;

    @Autowired
    private PetService petService;

    @Autowired
    private UserService usrService;





    // Get all the schedules from repo
    public List<Schedule> getAllSchedule(){
        List<Schedule> schedulesList = scheduleRepository.findAll();
        return schedulesList;
    }


    public Schedule save_Schedule(Schedule schedule){
        Schedule sch = scheduleRepository.save(schedule);
        return sch;
    }

    // get all employee schedules
    public List<Schedule> getAllEmployeeSchedule(long empID){

        // Use optional to check if the employee is present or not

        Optional<Employee> opEmp = Optional.of(empRepo.getOne(empID));
        if(opEmp.isPresent()){
            Employee employee =  opEmp.get();
            List<Schedule> empSchList = scheduleRepository.getAll_ContainsEmployee(employee);
            return empSchList ;
        }

        else return null;
    }



    // get all pet schedules
    public List<Schedule> getAllPetSchedule(long pID){

        // Use optional to check if the Pet is present or not

        Optional<Pet> opPet = Optional.of(petRepo.getOne(pID));
        if (opPet.isPresent()){
            Pet pet = opPet.get();
            List<Schedule> petSchList = scheduleRepository.getAll_ContainsPets(pet);
            return petSchList;
        }
        else return null ;
    }



    // get all customer schedules
    public List<Schedule> getAllCustomerSchedule(long custID){

        //get all schedule
        List<Schedule> allSchedule = scheduleRepository.findAll();

        // Use optional to check if the customer is present or not
        Optional<Customer> opCus = Optional.of(customerRepo.getOne(custID));

        if (opCus.isPresent()){
            //get customer data
           Customer customer = opCus.get();

           List<Schedule> cusSchList = new ArrayList<>();

           // loop inside schedule
           for(Schedule sch : allSchedule){

               // Get petlist for that schedule
               List<Pet> petList = sch.getPetList();

               // loop through that pet list
               for(Pet pet : petList){

                   // check if customer matches with pet customer
                   if (pet.getCustomer() == customer){

                       // add it to the list if matches
                       cusSchList.add(sch);
                   }
               }
           }
           return cusSchList ;
        }
        else return null ;
    }







}
