package com.udacity.jdnd.course3.critter.repository;

import com.udacity.jdnd.course3.critter.entity.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;





@Repository
@Transactional
//JpaRepository contains all CRUD Repository API manages with Pet Entity
public interface PetRepository extends JpaRepository<Pet,Long> {


    // get all the pets of a particular customer
    List<Pet> getAllPetsByCusID(Long cusID);
}
