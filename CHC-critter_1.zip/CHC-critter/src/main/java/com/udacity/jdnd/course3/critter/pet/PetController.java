package com.udacity.jdnd.course3.critter.pet;

import com.udacity.jdnd.course3.critter.entity.Customer;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.service.PetService;
import com.udacity.jdnd.course3.critter.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Handles web requests related to Pets.
 */
@RestController
@RequestMapping("/pet")
public class PetController {

    //import Pet and User Service

    @Autowired
    PetService petService;

    @Autowired
    UserService usrService;




    @PostMapping
    public PetDTO savePet(@RequestBody PetDTO petDTO) {
        // get the owner of the pet
        Customer owner = null;
        if( (Long)petDTO.getOwnerId() == null){
            return null;
        }
        else {

            // If ownerID exists
            // get the pet owner by owner ID
            owner = usrService.getCustomerByCusID(petDTO.getOwnerId());

        }


        // copy values from DTO to Pet Entity
        Pet pet = transformDTOToEntity(petDTO);

        //set the pet owner
        pet.setCustomer(owner);

        // Save the newly created Pet
        Pet pet1 = petService.savePet(pet);

        // Now convert the petEntity to petDTO and return
        return transformEntityToDTO(pet1);

    }






    @GetMapping("/{petId}")
    public PetDTO getPet(@PathVariable long petId) {
        // Get pet from pet Service by Pet ID
        Optional<Pet> opPet = Optional.ofNullable(petService.getPetByPetID(petId));

        if(opPet.isPresent()){
            //get the pet data
            Pet pet_Entity = opPet.get();

            //convert PetEntity to PetDTO and return
            PetDTO pet_DTO = transformEntityToDTO(pet_Entity);
            return pet_DTO;
        }
        else return null;
    }






    @GetMapping
    public List<PetDTO> getPets(){


        //Get all the pets
        List<Pet> pet_Entity_List = petService.getAllPets();


        List<PetDTO> pet_DTO_List = new ArrayList<>() ;


        // Now convert each petEntity into PetDTo
        // And add it to pet_DTO_List

        for(Pet pet_Entity : pet_Entity_List ){
            PetDTO pet_DTO = transformEntityToDTO(pet_Entity);
            pet_DTO_List.add(pet_DTO);
        }

        return pet_DTO_List;

    }


    @GetMapping("/owner/{ownerId}")
    public List<PetDTO> getPetsByOwner(@PathVariable long ownerId) {

        // Get Pet list of the owner
        List<Pet> ownerPetList = petService.getPetsByOwnerID(ownerId);



        List<PetDTO> ownerPet_DTO_List = new ArrayList<>() ;



        // Now convert each petEntity into PetDTo
        // And add it to ownerPet_DTO_List

        for(Pet pet_Entity : ownerPetList ){
            PetDTO pet_DTO = transformEntityToDTO(pet_Entity);
            ownerPet_DTO_List.add(pet_DTO);
        }

        // return the list
        return ownerPet_DTO_List;
    }








    //___________________Helper Methods_______________

    //This helper function converts dto to entity
    public Pet transformDTOToEntity(PetDTO pet_DTO){
        // create a new pet
        Pet petEntity = new Pet();

        //Set all values from PetDTO to the new Pet
        petEntity.setName(pet_DTO.getName());
        petEntity.setType(pet_DTO.getType());
        petEntity.setBirthDate(pet_DTO.getBirthDate());
        petEntity.setNotes(pet_DTO.getNotes());

        //return the Pet of Entity type
        return petEntity ;
    }



    //This helper function converts entity to DTO
    public PetDTO transformEntityToDTO(Pet pet_Entity){
        // create a new pet
        PetDTO pet_DTO = new PetDTO();

        //Set all values from PetEntity to the new PetDTO
        pet_DTO.setId(pet_Entity.getId());
        pet_DTO.setBirthDate(pet_Entity.getBirthDate());
        pet_DTO.setName(pet_Entity.getName());
        pet_DTO.setType(pet_Entity.getType());
        pet_DTO.setNotes(pet_Entity.getNotes());

        //Set ownerID from petEntity customer ID
        pet_DTO.setOwnerId(pet_Entity.getCustomer().getId());


        //return the Pet of DTO type
        return pet_DTO ;
    }

}
