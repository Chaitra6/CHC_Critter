package com.udacity.jdnd.course3.critter.user;

import com.udacity.jdnd.course3.critter.entity.Customer;
import com.udacity.jdnd.course3.critter.entity.Employee;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.service.PetService;
import com.udacity.jdnd.course3.critter.service.UserService;
import org.checkerframework.checker.units.qual.C;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.swing.text.html.parser.Entity;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Handles web requests related to Users.
 *
 * Includes requests for both customers and employees. Splitting this into separate user and customer controllers
 * would be fine too, though that is not part of the required scope for this class.
 */
@RestController
@RequestMapping("/user")
public class UserController {

    // import UserService and PetService
    @Autowired
    private UserService usrService;

    @Autowired
    private PetService petService;




    //______________________________CUSTOMER________________________________

    @PostMapping("/customer")
    public CustomerDTO saveCustomer(@RequestBody CustomerDTO customerDTO){

        Customer cus_Entity = customerTransformDTOtoEntity(customerDTO);

        Customer savedCustomer = usrService.saveCustomer(cus_Entity);

        CustomerDTO cus_DTO = customerTransformEntityToDTO(savedCustomer);

        return cus_DTO;
    }



    @GetMapping("/customer")
    public List<CustomerDTO> getAllCustomers(){
        //get all the customes
        List<Customer> customer_Entity_List = usrService.getAllCustomer();

        List<CustomerDTO> customer_DTO_List = new ArrayList<>();

        //Loop through customers, transform each customer to DTO type
        if(customer_Entity_List != null){
            for (Customer customer : customer_Entity_List){
                CustomerDTO customerDTO = customerTransformEntityToDTO(customer);
                customer_DTO_List.add(customerDTO);
            }
        }

        return customer_DTO_List;

    }







    @GetMapping("/customer/pet/{petId}")
    public CustomerDTO getOwnerByPet(@PathVariable long petId){
        //get owner by Pet ID
        Customer owner_Entity = usrService.getCustomerByPetID(petId);

        // convert to dto type
        CustomerDTO owner_DTO = customerTransformEntityToDTO(owner_Entity);

        return owner_DTO;
    }




    //________________________Customer Helper Methods____________________

    //This function converts from Customer Entity to Customer DTO type

    private CustomerDTO customerTransformEntityToDTO(Customer cus_Entity){

        // Create new Customer DTO Type
        CustomerDTO cus_DTO = new CustomerDTO();

        //Set all values from customer DTO type to Entity type
        cus_DTO.setId(cus_Entity.getId());

        cus_DTO.setName(cus_Entity.getName());

        cus_DTO.setPhoneNumber(cus_Entity.getPhoneNumber());

        cus_DTO.setNotes(cus_Entity.getNotes());

        //get all pets of the customer
        List<Pet> pet_List = cus_Entity.getPetList();

        List<Long> pet_ID_List = new ArrayList<>();

        //Loop through the pet_List, get each pet ID and add it to pet ID List
        for(Pet pet : pet_List){
            Long pID = pet.getId();
            pet_ID_List.add(pID);
        }

        // set petIDS of Customer DTO
        cus_DTO.setPetIds(pet_ID_List);

        // Return Customer of DTO type
        return cus_DTO;

    }


    //This function converts from Customer DTO to Customer Entity type
    public Customer customerTransformDTOtoEntity(CustomerDTO cus_DTO){

        // Create new Customer entity type variable
        Customer cus_Entity = new Customer();

        cus_Entity.setName(cus_DTO.getName());
        cus_Entity.setPhoneNumber(cus_DTO.getPhoneNumber());
        cus_Entity.setNotes(cus_DTO.getNotes());


        //get all petIDs
        List<Long> pet_ID_List = cus_DTO.getPetIds();

        List<Pet> pet_List = new ArrayList<>();

        //Loop through the pet_ID_List, get Pet by petID
        // and add it to pet_List
        for(long pID : pet_ID_List){
            Pet pet = petService.getPetByPetID(pID);
            pet_List.add(pet);
        }

        // set PetList of Customer entity type
        cus_Entity.setPetList(pet_List);

        return cus_Entity;
    }









    //_________________________________ EMPLOYEE Mapping _________________________

    @PostMapping("/employee")
    public EmployeeDTO saveEmployee(@RequestBody EmployeeDTO employeeDTO) {
        // Transform Emp DTO to Entity type
        Employee emp_Entity = empTransformDTOtoEntity(employeeDTO);

        //save the emp entity in repo
        Employee savedEmpEntity = usrService.saveEmployee(emp_Entity);

        // convert back the transformed emp Entity to DTO type and return
        return empTransformEntityToDTO(savedEmpEntity);


    }



    @PostMapping("/employee/{employeeId}")
    public EmployeeDTO getEmployee(@PathVariable long employeeId) {
        //Get employee by Emp ID
        Employee employee = usrService.getEmplByID(employeeId);

        //Transform from emp Entity Type to DTO type
        EmployeeDTO employee_DTO = empTransformEntityToDTO(employee);

        return employee_DTO;
    }






    @PutMapping("/employee/{employeeId}")
    public void setAvailability(@RequestBody Set<DayOfWeek> daysAvailable, @PathVariable long employeeId) {
       usrService.setEmpAvailability(employeeId, daysAvailable);
    }



    @GetMapping("/employee/availability")
    public List<EmployeeDTO> findEmployeesForService(@RequestBody EmployeeRequestDTO employeeDTO) {

        //get list of employees with skills and date
        List<Employee> empForService_Entity = usrService.getServiceEmployees(employeeDTO.getSkills(), employeeDTO.getDate());

        //Using stream to loop through empForService_Entity and
        // convert each employee Entity to DTO type
        List<EmployeeDTO> empForService_DTO = empForService_Entity.stream()
                .map(this::empTransformEntityToDTO).
                collect(Collectors.toList());

        return empForService_DTO;

    }






    //____________________Employee Helper Functions____________________

    //This function converts from Employee Entity to Employee DTO type

    private EmployeeDTO empTransformEntityToDTO(Employee emp_Entity){

        // create a new emp DTO variable
        EmployeeDTO emp_DTO = new EmployeeDTO();

        //set all the values from emp Entity type to emp DTO type
        emp_DTO.setId(emp_Entity.getId());

        emp_DTO.setName(emp_Entity.getName());

        emp_DTO.setSkills(emp_Entity.getSkills());

        emp_DTO.setDaysAvailable(emp_Entity.getDaysAvailable());

        return emp_DTO ;

    }



    // This function converts Employee DTO to Emp Entity type
    private Employee empTransformDTOtoEntity(EmployeeDTO emp_DTO){

        // create a new emp Entity type variable
        Employee emp_Entity = new Employee();


        //set all the values from emp DTO type to emp Entity type

        //emp ID is auto generated for entity type

        emp_Entity.setName(emp_DTO.getName());

        emp_Entity.setSkills(emp_DTO.getSkills());

        emp_Entity.setDaysAvailable(emp_DTO.getDaysAvailable());

        //return emp of entity type
        return emp_Entity ;

    }





}
