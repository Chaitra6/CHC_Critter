package com.udacity.jdnd.course3.critter.schedule;

import com.udacity.jdnd.course3.critter.entity.Employee;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.entity.Schedule;
import com.udacity.jdnd.course3.critter.service.PetService;
import com.udacity.jdnd.course3.critter.service.SchedulingService;
import com.udacity.jdnd.course3.critter.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles web requests related to Schedules.
 */
@RestController
@RequestMapping("/schedule")
public class ScheduleController {

    // import all the services

    @Autowired
    SchedulingService scheduleService;

    @Autowired
    PetService petService;

    @Autowired
    UserService usrService;



    @PostMapping
    public ScheduleDTO createSchedule(@RequestBody ScheduleDTO scheduleDTO) {

        // Conver SchDTO data to SchEntity
        Schedule scheduleTransformed = transformDTOtoEntity(scheduleDTO);

        // save the schEntity data
        Schedule savedSchedule = scheduleService.save_Schedule(scheduleTransformed);

        // convert the enitydata to DTO and return
        return transformEntityToDTO(savedSchedule);

    }

    @GetMapping
    public List<ScheduleDTO> getAllSchedules() {

        // Get all the schedules of entity type
        List<Schedule> schedule_Entity_List = scheduleService.getAllSchedule();

        List<ScheduleDTO> schedule_DTO_List  = new ArrayList<>();

        //Loop through ScheduleEntity list
        //Transform each schedule from schedule_Entity_List to DTO type
        for(Schedule sch_Entity : schedule_Entity_List){
            ScheduleDTO sch_DTO = transformEntityToDTO(sch_Entity);
            schedule_DTO_List.add(sch_DTO);
        }

        // Return DTO type list
        return schedule_DTO_List;

    }




    @GetMapping("/pet/{petId}")
    public List<ScheduleDTO> getScheduleForPet(@PathVariable long petId) {

        //Get all pet Schedules by Pet ID
        List<Schedule> pet_Entity_List = scheduleService.getAllPetSchedule(petId);

        //Instead of looping through 'for each loop' like above, I'm

        // Using Stream to loop through pet_Entity_List
        // pass each petSchedule of entity type to convert into DTO type
        // collect them into a List and save in pet_DTO_List
        List<ScheduleDTO> pet_DTO_List = pet_Entity_List.stream().
                map(this::transformEntityToDTO)
                .collect(Collectors.toList());



        return pet_DTO_List;

    }





    @GetMapping("/employee/{employeeId}")
    public List<ScheduleDTO> getScheduleForEmployee(@PathVariable long employeeId) {

        //Get all employee Schedule by EmpID
        List<Schedule> emp_Entity_List = scheduleService.getAllEmployeeSchedule(employeeId);


        // Using Stream to loop through emp_Entity_List
        // pass each emp Schedule of entity type to convert into DTO type
        // collect them into a List and save in emp_DTO_List
        List<ScheduleDTO> emp_DTO_List = emp_Entity_List.stream()
                .map(this::transformEntityToDTO).collect(Collectors.toList());



        return emp_DTO_List;


    }

    @GetMapping("/customer/{customerId}")
    public List<ScheduleDTO> getScheduleForCustomer(@PathVariable long customerId) {


        //Get all Customer Schedule by Customer ID
        List<Schedule> customer_Entity_List = scheduleService.getAllCustomerSchedule(customerId);


        // Using Stream to loop through customer_Entity_List
        // pass each Customer Schedule of entity type to convert into DTO type
        // collect them into a List and save in customer_DTO_List
        List<ScheduleDTO> customer_DTO_List = customer_Entity_List.stream()
                .map(this::transformEntityToDTO).collect(Collectors.toList());



        return customer_DTO_List;


    }



    //_________________________Helper Functions_______________________

    //This helper function converts ScheduleDTO to ScheduleEntity

    public Schedule transformDTOtoEntity(ScheduleDTO sch_DTO){

        //Create new Schedule
        Schedule schedule_Entity = new Schedule();

        schedule_Entity.setActivities(sch_DTO.getActivities());
        schedule_Entity.setDate(sch_DTO.getDate());
        schedule_Entity.setId(sch_DTO.getId());


        //Get all employee ID
        List<Long> emp_ID_List = sch_DTO.getEmployeeIds();

        List<Employee> employeeList = new ArrayList<>() ;

        //Loop through emp_ID_List, Find the Employee and add it to employeeList
        for(Long empID : emp_ID_List){
            employeeList.add(usrService.getEmplByID(empID));
        }


        //Get all Pet IDs
        List<Long> pet_ID_List = sch_DTO.getPetIds();

        List<Pet> petList = new ArrayList<>() ;

        //Loop through pet_ID_List, Find the Pet and add it to petList
        for(Long petID : pet_ID_List){
            petList.add(petService.getPetByPetID(petID));
        }


        schedule_Entity.setEmployees(employeeList);
        schedule_Entity.setPetList(petList);

        return schedule_Entity;
    }





    //This helper function converts ScheduleDTO to ScheduleEntity

    public ScheduleDTO transformEntityToDTO(Schedule sch_Entity) {

        ScheduleDTO schedule_DTO = new ScheduleDTO();

        schedule_DTO.setActivities(sch_Entity.getActivities());
        schedule_DTO.setDate(sch_Entity.getDate());
        schedule_DTO.setId(sch_Entity.getId());


        //Get all employees
        List<Employee> empList = sch_Entity.getEmployees();

        List<Long> emp_ID_List = new ArrayList<>() ;

        //Loop through employeeList, get employee ID and add it to emp_ID_List
        for(Employee emp : empList){
            emp_ID_List.add(emp.getId());
        }


        //Get all Pets
        List<Pet> petList = sch_Entity.getPetList();

        List<Long> pet_ID_List = new ArrayList<>() ;

        //Loop through Pets, get pet ID and add it to pet_ID_List
        for(Pet pet : petList){
            pet_ID_List.add(pet.getId());
        }


        schedule_DTO.setEmployeeIds(emp_ID_List);

        schedule_DTO.setPetIds(pet_ID_List);


        return schedule_DTO;

    }




}
