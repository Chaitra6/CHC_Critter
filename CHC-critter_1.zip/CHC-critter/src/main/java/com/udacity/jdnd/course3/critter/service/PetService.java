package com.udacity.jdnd.course3.critter.service;


import com.udacity.jdnd.course3.critter.entity.Customer;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.repository.CustomerRepository;
import com.udacity.jdnd.course3.critter.repository.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PetService {

    //Autowire Pet and Customer Repository

    @Autowired
    private PetRepository petRepo ;



    @Autowired
    private CustomerRepository cusRepo ;





// Get pet by pet ID
    public Pet getPetByPetID(Long id){
        // Use Optional to check if the value is present or not
        Optional<Pet> opPet = Optional.of(petRepo.getOne(id));
        if(opPet.isPresent()){
            //gets the pet
            Pet pet = opPet.get();
            return pet;
        }
        return null;
    }



// Save the pet
    public Pet savePet(Pet pet){
        Customer petOwner = pet.getCustomer();
        Pet pet1 = petRepo.save(pet);

        // add pet to the Owner petList
        if(petOwner != null){
            petOwner.addPet(pet1);
            cusRepo.save(petOwner);
        }
        //return the saved pet
        return pet1;
    }



// Get the owners List of pets
    public List<Pet> getPetsByOwnerID(Long ownerID )
    {


        // Use Optional to check if the Customer is present or not
        Optional<Customer> owner = Optional.of(cusRepo.getOne(ownerID));
        if(owner.isPresent())
        {
            // get the owner
            Customer petOwner = owner.get();
            List<Pet> allOwnerPets = petRepo.getAllPetsByCusID(ownerID);
            return allOwnerPets;
        }
        else {
            return null;
        }
    }




    // get all the pets from pet repository
    public List<Pet> getAllPets(){


        return petRepo.findAll();
    }




}
